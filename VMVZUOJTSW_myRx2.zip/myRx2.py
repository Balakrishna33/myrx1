from dataclasses import dataclass, field
from typing import List
from datetime import date
import copy

@dataclass(frozen=True)
class Address:
    street: str
    city: str
    state: str
    zip_code: str

@dataclass(frozen=True)
class ImmutableEmployee:
    name: str
    id: str
    date_of_joining: date
    addresses: List[Address] = field(default_factory=list)

    def __post_init__(self):
        
        object.__setattr__(self, 'addresses', copy.deepcopy(self.addresses))


if __name__ == "__main__":
    address1 = Address(street="Shakthinagar", city="Hyderabad", state="Telangana", zip_code="500074")
    address2 = Address(street="FCI Colony", city="Hyderabad", state="Telangana", zip_code="500070")

    employee = ImmutableEmployee(
        name="Balakrishna Kodadhala",
        id="630549",
        date_of_joining=date(2025, 1, 2),
        addresses=[address1, address2]
    )

    print(employee)