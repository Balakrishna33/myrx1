def sort_rgb_balls(array):
    low, mid, high = 0, 0, len(array) - 1

    while mid <= high:
        if array[mid] == 'B':
            array[low], array[mid] = array[mid], array[low]
            low += 1
            mid += 1
        elif array[mid] == 'G':
            mid += 1
        else:  
            array[mid], array[high] = array[high], array[mid]
            high -= 1

    return array


if __name__ == "__main__":
    input_balls = ['R', 'G', 'B', 'G', 'G', 'R', 'B', 'B', 'G']
    sorted_balls = sort_rgb_balls(input_balls)
    print(sorted_balls)