def find_minimum_platforms(arr, dep):
    arr.sort()
    dep.sort()

    n = len(arr)
    platforms_needed = 0
    max_platforms = 0

    arr_pointer, dep_pointer = 0, 0

    
    while arr_pointer < n and dep_pointer < n:
        
        if arr[arr_pointer] < dep[dep_pointer]:
            platforms_needed += 1
            arr_pointer += 1
            max_platforms = max(max_platforms, platforms_needed)
        else:  
            platforms_needed -= 1
            dep_pointer += 1

    return max_platforms


if __name__ == "__main__":
    arr = [9.00, 9.40]
    dep = [9.10, 12.00]
    print(find_minimum_platforms(arr, dep))